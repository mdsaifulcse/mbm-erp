<?php

namespace App\Http\Controllers\Hr\Reports;

use App\Http\Controllers\Controller;
use App\Models\Employee;
use App\Models\Hr\HrMonthlySalary;
use DB;
use Illuminate\Http\Request;

class CrossAnalysisController extends Controller
{
    public function index()
    {
        return view('hr.reports.cross_analysis.index');
    }

    public function report(Request $request)
    {
        $input = $request->all();
        $data['type'] = 'error';
        
        try {
            $data['input'] = $input;
            if(!is_array($input['category_data'])){
                $input['category_data'] = (array)$input['category_data'];
            }
            $type = $input['type'];

            $empquery = Employee::select(DB::raw('DATE_FORMAT(as_doj, "%Y-%m") as joinmonth'), $input['type'], DB::raw("COUNT(*) AS joincount"))
                ->whereIn($input['type'], $input['category_data'])
                ->whereBetween(DB::raw('DATE_FORMAT(as_doj, "%Y-%m")'), [date('Y-m', strtotime($input['month_from'])), date('Y-m', strtotime($input['month_to']))]);
                if($input['otnonot'] != ''){
                    $empquery->where('as_ot', $input['otnonot']);
                }
            $getEmployee = $empquery->orderBy('joinmonth', 'asc')
                    ->groupBy('joinmonth', $input['type'])
                    ->get()
                    ->groupBy($input['type'], true)
                    ->map(function($q){
                        return collect($q)->keyBy('joinmonth');
                    });
            
            $query = HrMonthlySalary::
                select(DB::raw("CONCAT(year,'-',month) AS yearmonth"), 'hr_as_basic_info.'.$input['type'], DB::raw("SUM(gross) AS totalSalary"), DB::raw('COUNT(CASE WHEN emp_status = 1 THEN emp_status END) AS empcount'), DB::raw('COUNT(CASE WHEN emp_status = 2 THEN emp_status END) AS resignemp, COUNT(CASE WHEN emp_status = 5 THEN emp_status END) AS leftemp'))
                ->join('hr_as_basic_info', 'hr_monthly_salary.as_id', 'hr_as_basic_info.associate_id')
                ->whereIn('hr_as_basic_info.'.$input['type'], $input['category_data'])
                ->whereBetween(DB::raw("CONCAT(year,'-',month)"), [date('Y-m', strtotime($input['month_from'])), date('Y-m', strtotime($input['month_to']))]);
                if($input['otnonot'] != ''){
                    $query->where('hr_as_basic_info.as_ot', $input['otnonot']);
                }
            $data['getSalary'] = $query->orderBy('yearmonth', 'asc')
                    ->groupBy('yearmonth', $input['type'])
                    ->get()
                    ->map(function($q, $k) use ($getEmployee, $type){
                        if(isset($getEmployee[$q->{$type}][$q->yearmonth])){
                            $q->joinemp = $getEmployee[$q->{$type}][$q->yearmonth]['joincount'];
                        }else{
                            $q->joinemp = 0;
                        }
                        $q->leftresignemp = $q->resignemp + $q->leftemp;
                        return $q;
                    })
                    ->groupBy($input['type'], true);
                        
            $data['unit'] = unit_by_id();
            $data['location'] = location_by_id();
            $data['department'] = department_by_id();
            $data['section'] = section_by_id();
            $data['subSection'] = subSection_by_id();
            $data['designation'] = designation_by_id();
            $data['type'] = 'success';
            return Response()->json($data);
            // return view('hr.reports.cross_analysis.report', $data);
        } catch (\Exception $e) {
            $data['message'] = $e->getMessage();
            return Response()->json($data);
        }
    }
}
