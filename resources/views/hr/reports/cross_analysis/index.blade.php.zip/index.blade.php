@extends('hr.layout')
@section('title', 'Cross Analysis')
@section('main-content')
@push('css')
<style>
   
</style>
@endpush
<div class="main-content">
  <div class="main-content-inner">
    <div class="breadcrumbs ace-save-state" id="breadcrumbs">
      <ul class="breadcrumb">
        <li>
          <i class="ace-icon fa fa-home home-icon"></i>
          <a href="#">Human Resource</a>
        </li>
        <li>
          <a href="#">Reports</a>
        </li>
        <li class="active"> Employee Cross Analysis</li>
      </ul><!-- /.breadcrumb -->
    </div>

    <div class="page-content">
      <div class="row">
        <div class="col">
          @php
            $yearMonth = date('Y-m');
          @endphp
          <cross-analysis :month="{{ json_encode($yearMonth) }}"></cross-analysis>  
        </div>
      </div>
    </div>
  </div>
</div>

@push('js')
  <script src="{{ asset('assets/js/bootstrap-datetimepicker.min.js') }}"></script>
@endpush
@endsection
