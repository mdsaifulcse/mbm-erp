
@foreach($getSalary as $group => $groupSalary)
	<div class="row">
		<div class="col-sm-6">
			<table class="table table-bordered table-hover table-head" style="width:100%;border:0 !important;margin-bottom:0;font-size:14px;text-align:left" border="1" cellpadding="5">
				<thead>
	                <tr>
	                	@php
	                		$format = $input['type'];
							if($format == 'as_department_id'){
								$head = 'Department';
								$body = $department[$group]['hr_department_name']??'';
							}elseif($format == 'as_designation_id'){
								$head = 'Designation';
								$body = $designation[$group]['hr_designation_name']??'';
							}elseif($format == 'as_section_id'){
								$head = 'Section';
								$body = $section[$group]['hr_section_name']??'';
							}elseif($format == 'as_subsection_id'){
								$head = 'Sub Section';
								$body = $subSection[$group]['hr_subsec_name']??'N/A';
							}elseif($format == 'as_location'){
								$head = 'Location';
								$body = $location[$group]['hr_location_name']??'N/A';
							}elseif($format == 'as_unit_id'){
								$head = 'Unit';
								$body = $unit[$group]['hr_unit_name']??'N/A';
							}else{
								$head = '';
							}
						@endphp
	                	@if($head != '')
	                    <th colspan="2">{{ $head }}</th>
	                    <th colspan="11">{{ $body }}</th>
	                    @endif
	                </tr>
	                <tr>
	                    <th width="2%">SL</th>
	                    <th>Year, Month</th>
	                    <th>Join Employee</th>
	                    <th>Left Employee</th>
	                    <th>Active Employee</th>
	                    <th class="text-right">Total Salary</th>
	                </tr>
	            </thead>
	            <tbody>
	            	@php $i=0; @endphp
	            	@foreach($groupSalary as $salary)
		            	<tr>
		            		<td>{{ ++$i }}</td>
		            		<td>{{ date('Y, F', strtotime($salary->yearmonth))}}</td>
		            		<td>{{ $salary->joinemp }}</td>
		            		<td>{{ ($salary->leftemp + $salary->resignemp) }}</td>
		            		<td>{{ $salary->empcount }}</td>
		            		<td class="text-right">{{ bn_money(round($salary->totalSalary,2)) }}</td>
		            	</tr>
	            	@endforeach
	            </tbody>
			</table>
		</div>
		<div class="col-sm-6">
			@php
				$data = [];
				$data['label'] = array_column($groupSalary->toArray(), 'yearmonth');
				$data['value'] = array_column($groupSalary->toArray(), 'totalSalary');
			@endphp
			<bar-chart :data="{{ json_encode($data) }}"></bar-chart>
		</div>
	</div>
	<br>
@endforeach